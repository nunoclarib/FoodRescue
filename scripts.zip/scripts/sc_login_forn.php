<?php
header('Location: ../mapa_fornecedor.php');